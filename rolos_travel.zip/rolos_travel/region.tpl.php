<?php if (!empty($content)): ?>
<?php print $content; ?>
<?php endif; ?>

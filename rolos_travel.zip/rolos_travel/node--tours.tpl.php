<?php if ($page): ?>	
	<div class="tours-full text-justify">
		<?php print render($content['field_slider_tour']); ?>
	</div>
	<div class="box">
        <div class="row">        			
			<div class="col-md-9 descripcion-tour">	
				<?php if($content['body']): ?>			
				<?php print render($content['body']); ?>	
				<?php endif; ?>			
			</div>				
			<div class="col-md-3 detalles-tour">
				<?php if($content['field_duration']): ?>					
				<?php print render($content['field_duration']); ?>			
				<?php endif; ?>	
				<?php if($content['field_price']): ?>					
				<?php print render($content['field_price']); ?>			
				<?php endif; ?>	
				<div class="col-md-6 btn-contact">
					<div class="contact">
		            	<?php if($content['field_contact']): ?>
			            <a href="<?php print $content['field_contact']['0']['#markup']; ?>?tours=<?php print $title; ?>" class="btn btn-success btn-contact" title="<?php print $content['field_contact']['#title']; ?>">
			                <?php print $content['field_contact']['#title']; ?>
			            </a>
			            <?php endif; ?>
		            </div>
				</div>
				<div class="col-md-6 btn-book">
					<div class="tour-links">
	            	 	<?php if($content['field_book_now']): ?>
	                    <div class="btns-tour contenedor-linkBook">
	                        <form action="<?php print $content['field_book_now']['0']['#markup']; ?>"><input name="tours" type="hidden" value="<?php print $title; ?>"><button class="btn-book-now" title="<?php print $content['field_book_now']['#title']; ?>">
	                        <?php print $content['field_book_now']['#title']; ?>
	                        </button></form>
	                    </div>
	                    <?php endif; ?>
		            </div>
				</div>
			</div>			
        </div>
    </div>
  <div class="tours-tabs">
  	<ul class="nav nav-tabs nav-tours" role="tablist">
  		<?php if(array_key_exists('field_itinerary',$content)): ?>
  			<li role="presentation" class="active">
            <a href="#itinerary" aria-controls="itinerary" role="tab" data-toggle="tab"><?php print $content['field_itinerary']["#title"]; ?></a>
            </li>
  		<?php endif; ?> 

  		<?php if(array_key_exists('field_include',$content)): ?>
  			<li role="presentation">
            <a href="#include" aria-controls="include" role="tab" data-toggle="tab"><?php print $content['field_include']["#title"]; ?></a>
            </li>
  		<?php endif; ?> 
		
		<?php if(array_key_exists('field_download_tour',$content)): ?>
  			<li role="presentation">
            <?php print render($content['field_download_tour'][0]); ?>
            </li>
  		<?php endif; ?> 
  	</ul>

  	<div class="tab-content">
  		<?php if(array_key_exists('field_itinerary',$content)): ?>
            <div role="tabpanel" class="tab-pane  active" id="itinerary"><?php print render($content['field_itinerary']); ?></div>
        <?php endif; ?>

        <?php if(array_key_exists('field_include',$content)): ?>
            <div role="tabpanel" class="tab-pane" id="include"><?php print render($content['field_include']); ?></div>
        <?php endif; ?>
        
  	</div>	
  </div>

<?php else: ?>
<div class="tours-teaser text-center"> 
</div>
<?php endif; ?>